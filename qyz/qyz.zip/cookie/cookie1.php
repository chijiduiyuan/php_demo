<?php
echo "<meta charset='utf8'/>";
 echo "欢迎".$_COOKIE['username'];



?>