<?php
setcookie('username','admin',time()+60); //设置cookie
//echo $_COOKIE['username'];
echo "<meta charset='utf8'/>";
echo "<a href='cookie1.php'>跳转</a>";

?>