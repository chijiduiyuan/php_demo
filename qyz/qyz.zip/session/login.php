<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>用户登录</title>
</head>
<body>
	<form method="post" action="session.php">
		用户名:<input type="text" name="username"><br>
		密码:<input type="pwd" name="pwd"><br>
		<input type="submit" value="登录" >
	</form>
</body>
</html>