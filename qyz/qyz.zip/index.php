<?php

define('APP_PATH','./App/'); //创建app应用目录
define('APP_DEBUG',true);//检测错误
require './ThinkPHP3.23/ThinkPHP.php';//包含核心文件







?>