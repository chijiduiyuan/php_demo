<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>这是login()方法</title>
</head>
<body>
	这是login控制器下的login()方法
</body>
</html>