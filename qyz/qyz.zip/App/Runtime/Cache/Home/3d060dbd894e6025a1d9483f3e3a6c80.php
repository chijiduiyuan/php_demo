<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>News控制器下的new()方法</title>
</head>
<body>
	<!-- 输出变量和数组 框架和原生-->
	<!-- <?php echo ($name); ?><br><?php echo ($sex); ?><br><?php echo ($age); ?><br>
	<?php echo $name.'<br>'.$sex.'<br>'.$age.'<br>'; ?>

	<?php echo ($person["name"]); ?><br><?php echo ($person["sex"]); ?><br><?php echo ($person["age"]); ?><br>
	<?php foreach($person as $val){ echo $val.'<br>'; } ?> -->
</body>
</html>