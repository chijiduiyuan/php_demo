<?php
	class Userlist{
		public function hh(){
			echo "<meta charset='utf8'/>";
			echo "这是Home下Userlist类里的hh()方法";
		}
	}



?>